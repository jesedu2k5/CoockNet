const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

// Ruta: POST /api/auth/login
router.post('/login', authController.login);

// ESTA LÍNEA ES OBLIGATORIA PARA QUE EXPRESS NO TIRE EL ERROR DE "argument handler must be a function"
module.exports = router;
const jwt = require('jsonwebtoken');
const JWT_SECRET = 'Super_Secreto_CoockNet_2026_!#'; // Debe ser idéntico al del authController

// Este es el cadenero principal
const verifyToken = (req, res, next) => {
    // 1. Busca el pase VIP en las cabeceras de la petición
    const authHeader = req.headers['authorization'];
    
    if (!authHeader) {
        return res.status(403).json({ error: 'Acceso denegado. No se proporcionó un token.' });
    }

    // El token suele enviarse como "Bearer eyJhbG..." así que lo separamos
    const token = authHeader.split(' ')[1]; 
    if (!token) {
        return res.status(403).json({ error: 'Formato de token inválido.' });
    }

    // 2. Verifica si el token es válido y no ha expirado
    jwt.verify(token, JWT_SECRET, (err, decoded) => {
        if (err) {
            return res.status(401).json({ error: 'Token inválido o expirado. Vuelve a iniciar sesión.' });
        }
        
        // 3. Si todo está bien, guarda los datos del usuario y déjalo pasar
        req.user = decoded; 
        next(); // ¡Adelante!
    });
};

// Cadenero exclusivo para administradores (Control de roles)
const isAdmin = (req, res, next) => {
    if (req.user.role_id !== 1) { // 1 es el ID del rol 'admin' en nuestra base de datos
        return res.status(403).json({ error: 'Acceso denegado. Requiere permisos de administrador.' });
    }
    next();
};

module.exports = { verifyToken, isAdmin };
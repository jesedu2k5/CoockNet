const db = require('../config/db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// En un entorno profesional, esto va en un archivo .env oculto.
const JWT_SECRET = 'Super_Secreto_CoockNet_2026_!#'; 

exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;

        // 1. Buscar al usuario por correo
        const [users] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
        
        // Si no existe, damos un mensaje genérico (Previene enumeración de usuarios)
        if (users.length === 0) {
            return res.status(401).json({ error: 'Correo o contraseña incorrectos' });
        }

        const user = users[0];

        // 2. Verificar la contraseña encriptada usando bcrypt
        const validPassword = await bcrypt.compare(password, user.password_hash);
        if (!validPassword) {
            return res.status(401).json({ error: 'Correo o contraseña incorrectos' });
        }

        // 3. Verificación de MFA (Lo dejaremos preparado para el siguiente paso)
        if (user.mfa_enabled) {
            return res.json({ message: 'MFA requerido', userId: user.id, mfa: true });
        }

        // 4. Generar el JWT Seguro con expiración (Requisito de tu documento)
        const token = jwt.sign(
            { id: user.id, role_id: user.role_id, username: user.username },
            JWT_SECRET,
            { expiresIn: '1h' } // El token expira en 1 hora
        );

        // 5. Registrar la sesión en la Base de Datos (Manejo de Multisesiones)
        const ip = req.ip || req.connection.remoteAddress;
        const userAgent = req.headers['user-agent'] || 'Desconocido';

        // Opcional para la rúbrica: Si quieres que solo haya UNA sesión activa a la vez,
        // puedes invalidar las anteriores ejecutando esto antes del INSERT:
        // await db.query('UPDATE sessions SET is_active = 0 WHERE user_id = ?', [user.id]);

        await db.query(
            'INSERT INTO sessions (user_id, session_token, ip_address, user_agent) VALUES (?, ?, ?, ?)',
            [user.id, token, ip, userAgent]
        );

        // 6. Respuesta exitosa
        res.json({
            message: 'Login exitoso',
            token,
            user: { 
                id: user.id, 
                username: user.username, 
                role_id: user.role_id 
            }
        });

    } catch (error) {
        console.error('Error en login:', error);
        res.status(500).json({ error: 'Error interno del servidor' });
    }
};